<?php $__env->startSection('main'); ?>
    <h1>i tak davay dumat </h1>
    <p>Моё имя... Sa mer saytna</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/newPrj/resources/views/about.blade.php ENDPATH**/ ?>