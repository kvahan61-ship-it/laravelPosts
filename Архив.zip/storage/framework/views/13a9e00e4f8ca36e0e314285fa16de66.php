<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <title>Layout</title>
</head>
<body>
<header>
    <div class="linksHeader">
        <nav>
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('about')); ?>">About</a></li>
        </nav>
    </div>
    <div class="registerPart">
        <?php if (isset($component)) { $__componentOriginalee8f03fd2317527e47026beecb975942 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8f03fd2317527e47026beecb975942 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.registerPart','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('registerPart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8f03fd2317527e47026beecb975942)): ?>
<?php $attributes = $__attributesOriginalee8f03fd2317527e47026beecb975942; ?>
<?php unset($__attributesOriginalee8f03fd2317527e47026beecb975942); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8f03fd2317527e47026beecb975942)): ?>
<?php $component = $__componentOriginalee8f03fd2317527e47026beecb975942; ?>
<?php unset($__componentOriginalee8f03fd2317527e47026beecb975942); ?>
<?php endif; ?>
    </div>
</header>
<main>
    <?php echo $__env->yieldContent('main'); ?>
</main>
</body>
</html>
<?php /**PATH C:\laragon\www\newPrj\resources\views/layouts/layout.blade.php ENDPATH**/ ?>