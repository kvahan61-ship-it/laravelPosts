<?php $__env->startSection('main'); ?>
    <div>
        <div>
            <h1><?php echo e($post->id); ?> . <?php echo e($post->title); ?></h1>
        </div>
        <div>
            <a href="<?php echo e(route('post.edit',$post->id)); ?>">Update</a>
        </div>
        <div>
            <form action="<?php echo e(route('post.delete',$post->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/newPrj/resources/views/posts/show.blade.php ENDPATH**/ ?>