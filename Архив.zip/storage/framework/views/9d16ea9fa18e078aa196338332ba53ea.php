<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <title>MySocial</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<?php if(auth()->guard()->check()): ?>
<header class="main-header">
    <div class="logo">
        <a href="<?php echo e(route('home')); ?>">MySocial</a>
    </div>

    <nav>
        <ul class="nav-links">
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('saved')); ?>">Saved</a></li>
            <li><a href="<?php echo e(route('post.create')); ?>" class="btn-create">+ Create Post</a></li>
        </ul>
    </nav>

    <div class="registerPart">
        
        <?php if(auth()->guard()->check()): ?>
            <div class="user-profile">
                <span class="username"><?php echo e(auth()->user()->name); ?></span>
                <div class="avatar-container">
                    <?php if(auth()->user()->avatar): ?>
                        <img src="<?php echo e(asset('storage/' . auth()->user()->avatar)); ?>" alt="avatar" class="avatar-image">
                    <?php else: ?>
                        <div class="avatar-placeholder">
                            
                            <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" style="background:none; border:none; color:red; cursor:pointer;">Exit</button>
                </form>
            </div>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginalee8f03fd2317527e47026beecb975942 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee8f03fd2317527e47026beecb975942 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.registerPart','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('registerPart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee8f03fd2317527e47026beecb975942)): ?>
<?php $attributes = $__attributesOriginalee8f03fd2317527e47026beecb975942; ?>
<?php unset($__attributesOriginalee8f03fd2317527e47026beecb975942); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee8f03fd2317527e47026beecb975942)): ?>
<?php $component = $__componentOriginalee8f03fd2317527e47026beecb975942; ?>
<?php unset($__componentOriginalee8f03fd2317527e47026beecb975942); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
</header>
<?php endif; ?>
<main>
    <?php echo $__env->yieldContent('main'); ?>
</main>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/newPrj/resources/views/layouts/layout.blade.php ENDPATH**/ ?>