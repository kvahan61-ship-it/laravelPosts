<?php $__env->startSection('main'); ?>
    <div class="instagram-feed">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post-card">

                <div class="post-header">
                    <div class="avatar-small-container">
                        <?php if($post->user && $post->user->avatar): ?>
                            <img src="<?php echo e(asset('storage/' . $post->user->avatar)); ?>" alt="avatar" class="avatar-small-img">
                        <?php else: ?>
                            <div class="avatar-small-placeholder">
                                <?php echo e(strtoupper(substr($post->user->name ?? 'U', 0, 1))); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="username">User_<?php echo e($post->id); ?></div>
                </div>
                <h3><?php echo e($post->title); ?></h3>

                <div class="post-photo">
                    <?php if($post->image): ?>
                        <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="post-main-image" alt="post">
                    <?php else: ?>
                        <div style="height: 300px; background: #fafafa; display: flex; align-items: center; justify-content: center; color: #ccc;">
                            No Image
                        </div>
                    <?php endif; ?>
                </div>
                <div class="post-actions">
                    <div class="left-actions">
                        <button class="action-btn" title="Like"><i class="fa fa-heart-o" aria-hidden="true"></i></button>
                        <button class="action-btn" title="Comment"><i class="fa fa-commenting" aria-hidden="true"></i></button>
                    </div>
                    <div class="right-actions">
                        <button class="action-btn" title="Save"><i class="fa fa-bookmark-o" aria-hidden="true"></i></button>
                    </div>
                </div>













            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/newPrj/resources/views/posts/index.blade.php ENDPATH**/ ?>