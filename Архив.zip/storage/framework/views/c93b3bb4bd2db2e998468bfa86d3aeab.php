<?php $__env->startSection('main'); ?>
    <div class="create-post-container">
        <div class="post-form-card">
            <div class="form-header">
                <h2>Новая публикация</h2>
                <p>Поделитесь моментом с друзьями в MySocial</p>
            </div>

            <form action="<?php echo e(route('post.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                
                <div class="form-group">
                    <label for="title">О чем вы думаете?</label>
                    <textarea name="title" id="title" class="form-input" placeholder="Введите описание вашего поста..." required></textarea>
                </div>

                
                <div class="form-group">
                    <label>Добавьте фото</label>
                    <div class="file-upload-wrapper">
                        <input type="file" name="image" id="image" accept="image/*" class="file-input-hidden" onchange="previewImage(event)">
                        <label for="image" class="file-upload-label">
                            <span class="upload-icon">📸</span>
                            <span id="file-name">Выберите изображение</span>
                        </label>
                    </div>
                    
                    <div id="image-preview-container" class="image-preview" style="display: none;">
                        <img id="output-image" src="#" alt="Preview">
                    </div>
                </div>

                <button type="submit" class="btn-publish">Опубликовать</button>
            </form>
        </div>
    </div>

    
    <script>
        function previewImage(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById('output-image');
                var container = document.getElementById('image-preview-container');
                var labelText = document.getElementById('file-name');

                output.src = reader.result;
                container.style.display = 'block';
                labelText.innerText = event.target.files[0].name;
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/newPrj/resources/views/posts/create.blade.php ENDPATH**/ ?>