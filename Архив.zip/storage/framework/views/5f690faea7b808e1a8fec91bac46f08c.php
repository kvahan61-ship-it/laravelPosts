<div class="post-card">

    <div class="post-header">
        <div class="avatar-small-container">
            <?php if($post->user && $post->user->avatar): ?>
                <img src="<?php echo e(asset('storage/' . $post->user->avatar)); ?>" alt="avatar" class="avatar-small-img">
            <?php else: ?>
                <div class="avatar-small-placeholder">
                    <?php echo e(strtoupper(substr($post->user->name ?? 'U', 0, 1))); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="username">User_<?php echo e($post->id); ?></div>
    </div>
    <h3><?php echo e($post->title); ?></h3>

    <div class="post-photo">
        <?php if($post->image): ?>
            <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="post-main-image" alt="post">
        <?php else: ?>
            <div style="height: 300px; background: #fafafa; display: flex; align-items: center; justify-content: center; color: #ccc;">
                No Image
            </div>
        <?php endif; ?>
    </div>
    <div class="post-actions">
        <div class="left-actions">
            <button class="action-btn" title="Like"><i class="fa fa-heart-o" aria-hidden="true"></i></button>
            <button class="action-btn" title="Comment"><i class="fa fa-commenting" aria-hidden="true"></i></button>
        </div>
        <div class="right-actions">
            <form action="<?php echo e(route('post.save', $post->id)); ?>" method="POST" style="display: inline;">
                <?php echo csrf_field(); ?>
                <button type="submit" class="action-btn" title="Save">
                    <?php if(auth()->user()->savedPosts->contains($post->id)): ?>
                        
                        <i class="fa fa-bookmark" aria-hidden="true" style="color: #262626;"></i>
                    <?php else: ?>
                        
                        <i class="fa fa-bookmark-o" aria-hidden="true"></i>
                    <?php endif; ?>
                </button>
            </form>
        </div>
    </div>

    
    

    
    
    

    
    
    
    

</div>
<?php /**PATH /Applications/MAMP/htdocs/newPrj/resources/views/posts/post.blade.php ENDPATH**/ ?>