<?php $__env->startSection('main'); ?>
    <div class="auth-container">
        <form action="<?php echo e(route('register.store')); ?>" method="post" enctype="multipart/form-data" class="auth-form">
            <?php echo csrf_field(); ?>
            <h1>Create Account</h1>
            <p class="auth-subtitle">Join MySocial community today</p>

            <?php if($errors->any()): ?>
                <div class="error-alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="form-grid">
                
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="John Doe">
                </div>

                
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="example@mail.com">
                </div>

                
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="phoneNumber" value="<?php echo e(old('phoneNumber')); ?>" placeholder="+374 XX XXXXXX">
                </div>

                
                <div class="form-group">
                    <label>Gender</label>
                    <select name="gender">
                        <option value="" disabled selected>Select gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>

                
                <div class="form-group full-width">
                    <label>Profile Picture</label>
                    <input type="file" name="avatar" accept="image/*" class="file-input">
                </div>

                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="••••••••">
                </div>

                
                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="password_confirmation" placeholder="••••••••">
                </div>
            </div>

            <button type="submit" class="buttReg">Register Now</button>

            <p class="auth-footer">Already have an account? <a href="<?php echo e(route('login')); ?>">Log in</a></p>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/newPrj/resources/views/auth/register.blade.php ENDPATH**/ ?>