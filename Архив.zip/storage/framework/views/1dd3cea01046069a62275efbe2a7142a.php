<?php $__env->startSection('main'); ?>
    <form action="<?php echo e(route('login.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <h1>login</h1>
        <div class="namePart">
            <h5>Email:<span><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span></h5>
            <input type="text" name="email">
        </div>
        <div class="passPart">
            <h5>Password:<span><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span></h5>
            <input type="password" name="password">
        </div>
        <button type="submit" class="buttReg">Login</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\newPrj\resources\views/auth/login.blade.php ENDPATH**/ ?>