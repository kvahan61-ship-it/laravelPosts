<?php $__env->startSection('main'); ?>
    <h1>i tak davay dumat </h1>
    <p>Моё имя... Esh</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\newPrj\resources\views/home.blade.php ENDPATH**/ ?>