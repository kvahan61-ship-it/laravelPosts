<?php $__env->startSection('main'); ?>
    <div class="auth-container">
        <form action="<?php echo e(route('login.store')); ?>" method="post" class="auth-form">
            <?php echo csrf_field(); ?>
            <h1>Welcome Back</h1>
            <p class="auth-subtitle">Log in to your MySocial account</p>

            <?php if($errors->any()): ?>
                <div class="error-alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="form-group">
                <label>Email or Phone Number</label>
                <input type="text" name="login" value="<?php echo e(old('login')); ?>" placeholder="example@mail.com or +374..." required autofocus>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>

            <button type="submit" class="buttReg">Login</button>

            <p class="auth-footer">Don't have an account? <a href="<?php echo e(route('register')); ?>">Sign up</a></p>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/newPrj/resources/views/auth/login.blade.php ENDPATH**/ ?>