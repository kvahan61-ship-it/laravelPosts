<div class="authBlock">
    <?php if(auth()->guard()->check()): ?>
        <h3><?php echo e(auth()->user()->name); ?></h3>

        <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline; margin-left: 10px;">
            <?php echo csrf_field(); ?>
            <button type="submit">Выйти</button>
        </form>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('register')); ?>" class="buttReg">Registration</a> /
        <a href="<?php echo e(route('login')); ?>" class="buttReg">Login</a>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\newPrj\resources\views/components/registerPart.blade.php ENDPATH**/ ?>